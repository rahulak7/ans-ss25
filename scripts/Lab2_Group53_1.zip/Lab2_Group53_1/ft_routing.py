"""
 Copyright (c) 2025 Computer Networks Group @ UPB

 Permission is hereby granted, free of charge, to any person obtaining a copy of
 this software and associated documentation files (the "Software"), to deal in
 the Software without restriction, including without limitation the rights to
 use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 the Software, and to permit persons to whom the Software is furnished to do so,
 subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 """

#!/usr/bin/env python3

from ryu.base import app_manager
from ryu.controller import mac_to_port
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.mac import haddr_to_bin
from ryu.lib.packet import packet
from ryu.lib.packet import ipv4
from ryu.lib.packet import arp

from ryu.topology import event, switches
from ryu.topology.api import get_switch, get_link, get_host, get_all_host, get_all_link
from ryu.app.wsgi import ControllerBase
from ryu.lib.packet import ethernet
from ryu.lib.packet import ether_types
from collections import defaultdict
import heapq
from pprint import pformat

import topo


class FTRouter(app_manager.RyuApp):

    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(FTRouter, self).__init__(*args, **kwargs)
        self.network_graph = defaultdict(dict)
        self.mac_to_port = {}
        self.host_mac_to_port = {}

       # Topology discovery
    @set_ev_cls(event.EventSwitchEnter)
    def get_topology_data(self, ev):
        # Switches and links in the network
        switches = get_switch(self, None)
        links = get_link(self)

    def get_host_mac_by_switch_port(self, dpid, port_no):
        all_hosts = get_all_host(self)
        for host in all_hosts:
            if host.port.dpid == dpid and host.port.port_no == port_no:
                mac = str(host.mac)
                return mac
        return None

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        self.logger.info(f"Switch connected: dpid={datapath.id}")
        
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        
        # Install default table-miss flow entry (send to controller)
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
        self.add_flow(datapath, 0, match, actions)

    # Add a flow entry to the flow-table
    def add_flow(self, datapath, priority, match, actions):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        # Construct flow_mod message and send it
        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(datapath=datapath, priority=priority,
                                match=match, instructions=inst)
        datapath.send_msg(mod)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        pkt = packet.Packet(msg.data)
        eth_pkt = pkt.get_protocol(ethernet.ethernet)
        ip_pkt = pkt.get_protocol(ipv4.ipv4)
        arp_pkt = pkt.get_protocol(arp.arp)
        
        if arp_pkt:
            in_port = msg.match['in_port']
            self.logger.info(f"ARP packet: {arp_pkt.src_ip} -> {arp_pkt.dst_ip}")
            src_ip = arp_pkt.src_ip
            dst_ip = arp_pkt.dst_ip

            dst_ip_str = str(dst_ip)
            dst_ip_parts = dst_ip_str.split(".")
            dst_dpid = int(dst_ip_parts[1]+dst_ip_parts[2])
            last_port = int(dst_ip_parts[3])
            dst_pod = int(dst_ip_parts[1])
            out_port = []
            src_ip_str = str(src_ip)
            src_ip_parts = src_ip_str.split(".")
            src_dpid = int(src_ip_parts[1]+src_ip_parts[2])
            src_pod = int(src_ip_parts[1])
            
            in_port = msg.match['in_port']
            dst_eth = self.get_host_mac_by_switch_port(dst_dpid, last_port)

            
            # suffix matching for inter pod traffic
            if dst_pod == src_pod:
                if dst_dpid == datapath.id:
                    out_port.append(last_port)
                else:
                    if(datapath.id % 10) in (1,2):
                        out_port.append(3)
                        out_port.append(4)
                    else:
                        if(dst_dpid % 10 == 1):
                            out_port.append(1)
                        else:
                            out_port.append(2)
            # prefix matching for intra pod traffic
            else:
                if datapath.id in (5,6,7,8):
                    out_port.append(dst_pod)
                elif(datapath.id % 10) in (1,2):
                    if in_port in (1,2):
                        out_port.append(3)
                        out_port.append(4)
                    else:
                        out_port.append(last_port)
                else:
                    if in_port in (3,4):
                        if(dst_dpid % 10 == 1):
                            out_port.append(1)
                        else:
                            out_port.append(2)
                    else:
                        out_port.append(3)
                        out_port.append(4)
            #Install flows with priority
            priority = 10
            for port in out_port:
                actions = [parser.OFPActionOutput(port)]
                match = parser.OFPMatch(in_port=in_port, eth_dst=dst_eth)
                self.logger.info(f'flow added priority = {priority} outport= {port}')
                self.add_flow(datapath, priority, match, actions)
                priority = priority-1

            actions = [parser.OFPActionOutput(out_port[0])]
            out_port.clear()
            data = None
            if msg.buffer_id == ofproto.OFP_NO_BUFFER:
                data = msg.data
            out = parser.OFPPacketOut(datapath=datapath, buffer_id=msg.buffer_id, 
                                        in_port=in_port,actions=actions, data=data)
            self.logger.info(f'sending message to {out_port[0]}')
            #Send packet out message
            datapath.send_msg(out)
